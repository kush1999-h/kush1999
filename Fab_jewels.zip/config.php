<?php
define("DB_Host","localhost");
define("DB_user","sahoshib_fabjewels");
define("DB_password","{LbK0(B.l7.o");
define("DB_database","sahoshib_fav_jewels");

$mysqli = new mysqli(DB_Host,DB_user,DB_password,DB_database);
?>