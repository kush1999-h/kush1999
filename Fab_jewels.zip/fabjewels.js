// const name = document.getElementById("name");
// const email = document.getElementById("email");
// const messege = document.getElementById("messege");

// const sendbtn = document.getElementById("sendbtn");

// const database = firebase.database();

// sendbtn.addEventListener('click', (e) => {
//     e.preventDefault();

//     database.ref('/users/' + name.value).set({
//         name: name.value,
//         email = email.value,
//         messege = messege.value
//     });

// });