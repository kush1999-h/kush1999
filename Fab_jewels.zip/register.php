<?php
$email = $_POST['E-mail'];
$username = $_POST['username'];
$password = $_POST['password'];

if(!empty($email) || !empty($username) || !empty($password)){
    $host=
} else{
    echo "All field are required";
    die();
}
?>